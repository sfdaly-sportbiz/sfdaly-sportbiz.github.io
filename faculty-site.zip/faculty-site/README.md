# Your Faculty Website

A five-page academic site: About, Teaching, Research, Consulting, and CV —
built as plain HTML/CSS so it's easy to edit and free to host.

## 1. Personalize it

The site is now populated with your real information from your CV — name,
appointments, publications, presentations, and consulting projects. A few
small bracketed placeholders remain (office room number, office hours, and
a spot to attach a downloadable CV PDF if you want one) — search for `[` in
each file to find them.

Files:
- `index.html` — About / homepage
- `teaching.html` — Courses & curriculum
- `research.html` — Articles & publications
- `consulting.html` — Consulting & advisory work
- `cv.html` — Full CV
- `css/style.css` — All styling (colors, fonts, layout) lives here

## 2. Put it on GitHub Pages (free hosting)

You'll need a free [GitHub](https://github.com) account. Then:

1. **Create a repository.** On github.com, click the **+** in the top right →
   **New repository**. Name it exactly `your-username.github.io`
   (replace `your-username` with your actual GitHub username). Set it to
   **Public**. Click **Create repository**.

2. **Upload your files.** On the new repo's page, click
   **uploading an existing file**. Drag in `index.html`, `teaching.html`,
   `research.html`, `consulting.html`, `cv.html`, and the whole `css` folder.
   Scroll down and click **Commit changes**.

3. **Turn on Pages.** Go to the repo's **Settings** tab → **Pages** (left
   sidebar). Under "Build and deployment," make sure **Source** is set to
   **Deploy from a branch**, and the branch is set to `main` / `root`.
   Click **Save**.

4. **Wait about a minute**, then visit `https://your-username.github.io` —
   your site is live.

Any time you want to update the site: edit the file locally, then on
github.com open that file in the repo, click the pencil (edit) icon, paste
in your changes, and commit. The live site updates within a minute or two.

## 3. Optional: a custom domain

If you'd rather have `yourname.com` than `yourname.github.io`, buy a domain
from any registrar (Namecheap, Google Domains successor Squarespace, etc.,
roughly $12–15/year), then follow GitHub's guide for
["Configuring a custom domain for a GitHub Pages site"](https://docs.github.com/en/pages/configuring-a-custom-domain-for-your-github-pages-site)
— it's a DNS record and one settings field, no code changes needed.

## Notes on the design

- Type is set in Libre Caslon (headings) and Source Serif 4 (body), loaded
  from Google Fonts via the `@import` at the top of `style.css`.
- The small numbered notes in the body text (¹) are **sidenotes** — on wide
  screens they sit in the margin next to the text they annotate; on
  narrower screens they collapse into inline notes automatically. Use them
  for asides, caveats, or citations by copying the
  `<span class="sidenote-number">` / `<span class="sidenote">` pattern
  already in the pages.
- Colors and fonts are defined once at the top of `style.css` under `:root`
  — change a value there and it updates everywhere.
